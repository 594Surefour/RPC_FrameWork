cp config/git-hooks/pre-commit .git/hooks/
chmod +x .git/hooks/pre-commit
