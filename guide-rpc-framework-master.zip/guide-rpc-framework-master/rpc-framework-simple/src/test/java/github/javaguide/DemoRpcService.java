package github.javaguide;

public interface DemoRpcService {
    String hello();
}
